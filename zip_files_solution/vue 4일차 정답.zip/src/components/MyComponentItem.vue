<template>

  <div>
    <h1>MyComponentItem.vue</h1>
  </div>

</template>

<script setup>


</script>

<style scoped>
  h1 {
    color: green;
  }
</style>