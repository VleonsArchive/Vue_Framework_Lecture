<template>

  <div>
    <Parent/>
  </div>

</template>

<script setup>

  import Parent from '@/components/Parent.vue';

</script>

<style scoped>


</style>